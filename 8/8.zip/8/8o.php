<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * from students where fname='$_POST[fname]'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) 
{
    echo "First Name: " . $row["fname"]. "<br>Last Name: " . $row["lname"]. "<br>Age: " . $row["age"]. "<br>Address: " . $row["address"].  "<br>Pincode: " . $row["pincode"]. "<br>";
  }
} else {
  echo "0 results";
}
$conn->close();
?>

